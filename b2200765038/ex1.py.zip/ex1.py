N = int(input("number"))
print(sum(range(1,N+1,2)))
print(sum(range(2,N+1,2))/(N//2))

