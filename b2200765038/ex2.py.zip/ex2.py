email = input("Please enter your email: ")
list1 = list(email)
x = 0
y = 0
for i in list1:
    if i == '@':
     x = 1

for i in list1:
    if i == '.':
        y = 1

if x == 1 and y == 1:
    print("Your email is correct.")
else:
    print("Your email is not correct")
