import random

number=random.randint(1,20)

while True :

    enternumber = int(input("Please guess a number between 1 and 20:"))
    if enternumber<number :
        print("Please increase your number")

    elif (enternumber>number) :
        print("Please decrease your number")

    elif enternumber==number :
        print("Your guess is correct the number is {}".format(number))
        break



